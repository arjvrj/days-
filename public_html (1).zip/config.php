

<?php
return array (
  'db_host' => 'localhost',
  'db_name' => 'u760786862_pandu',
  'db_user' => 'u760786862_chinnu',
  'db_pass' => 'Panduchinu@22',
  'site_url' => 'https://reviewvai.in',
  'app_name' => 'ReviewAI',
  'owner_email' => '',
  'installed' => false,
);
