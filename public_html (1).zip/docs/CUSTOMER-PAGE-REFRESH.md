# Customer review page — UI/UX refresh

Third pass on `review.php`, the page a stranger opens from a QR code. It was
reviewed on a phone (the screenshot the business sent from the live site) and
three things were wrong.

## 1. The business logo was a grey slab

The stored logo is a path inside the app (`assets/uploads/…`). The page echoed it
raw, and when the file was not there the browser drew the **alt text** in a grey
box — which on a public page looks like a broken site.

Now, before the page is drawn:

```php
$logoUrl = '';
if (!empty($business['logo'])) {
    $logoFile = __DIR__ . '/' . ltrim((string)$business['logo'], '/');
    if (is_file($logoFile)) $logoUrl = url((string)$business['logo']);
}
```

- the file is checked, so a deleted upload cannot break the header;
- the URL goes through `url()`, so an install in a subfolder works;
- with no usable logo the header shows the business's **own initial** on a violet
  disc instead of an empty frame.

## 2. Nothing said where the customer was

The "2" badge appeared on the topics block with no step 1 anywhere. There is now
a three-step rail above the flow — **Rate → Topics → Draft** — that JavaScript
moves as the customer advances (`rgSetStep`, called from `selectRating`,
`showPrivateFeedback`, the draft result and the feedback success). It is purely
visual: it gates nothing, and with JavaScript off step 1 stays highlighted, which
is where everyone starts.

## 3. The call to action was hard to read

Pale lavender with white text is about **2.2:1** contrast. The primary button is
now the same palette's deep violet — about **8:1** — and the disabled state is a
soft lilac pill with readable text plus one line of help underneath that says
what is missing ("Pick a topic or write a line to continue"). That line hides
itself the moment the button becomes usable.

## Everything else in the pass

| Before | Now |
| --- | --- |
| Business name in a 245px plate on a grey block | A full-width header card, logo disc overlapping the top edge |
| Topic chips were grey pills; a pick was hard to see | Selected chips fill violet, turn white and gain a ✓; a `0 / 3` counter chip fills as topics are picked |
| Three lines of grey help text under the chips | One sentence |
| Details box: long placeholder, floating grey counter | Short placeholder, counter as a chip, violet focus ring |
| Language was a bare label + select | A bordered row that matches the inputs |
| "Prefer to tell the business privately?" was an underlined link | A full-width outlined button |
| Name / phone fields were 40% wide | Full width |
| "Copy" under each draft was a small underlined link | A 34px outlined button |
| Missing Google link was a bare grey sentence | A soft amber notice with a marker |
| — | Draft cards get a violet ring when picked; radio uses the page's violet |

New file: `app/assets/css/customer-refresh.css`, loaded last, after `customer.css`
(generated, never edited) and `customer-premium.css` (the earlier premium layer).
Additive only, no CDN, no `@import`, same fonts and palette. `review.php` changed
in the head, the header, the progress rail, the topics heading, the CTA and five
small JavaScript hooks.

## Nothing functional moved

Same flow, same endpoints, same CSRF token, same "never posted automatically",
same text the customer can edit, same private-feedback behaviour at every rating.

## Proof

```
php-lint               43/43 files parse cleanly
check-links            every local asset reference resolves
test-review-flow       108/108   (stars, keyboard, chips, drafts, copy, private, Google)
test-social-links      27/0
test-public-csrf       12/12
test-review-endpoint   16/0
test-security          119/119
test-qr                11/0
verify-assets          homepage 0 diffs, dashboard 0 diffs
audit-dashboard        0 undocumented classes, 0 remote assets
```

Screenshots (regenerate with `node tools/render-page.mjs review` and the driver in
`docs/screenshots/`, which is a build artefact and not in the ZIP):

```
reviews-before-mobile.png / review-after-mobile.png
review-after-drafts-mobile.png      the drafts step
review-after-private-mobile.png     1–3 star private form
review-after-desktop.png
```

## One thing only the business can fix

The live page said **"The Google review link is not available"**. That is not a
bug in the page: the card has no Google review URL saved. Dashboard → Settings →
Google review link, save, and the button and the direct link appear. The notice
stays until then, by design — the page never sends a customer to a generic Google
search for someone else's business.

## Cream finish (matching the approved design)

A fourth stylesheet, `app/assets/css/customer-cream.css`, is loaded last on
`review.php` only and moves the page onto the approved palette:

| Token | Value | Used for |
|---|---|---|
| primary | `#5425E8` | links, chips text, step badge, buttons |
| deep | `#4820D8` | button gradient end |
| navy | `#151832` | headings, business name, field labels |
| cream | `#FBF8F2` | page background |
| lavender | `#F0E9FF` | chips, name pill, current step |
| gold | `#FFB51B` | stars |
| line | `#EAE3F8` | borders |

What it changes: the cream page with soft violet glows, one white rounded card
with a soft lavender shadow, the round gradient logo above the business-name
pill, lavender topic chips with violet text, cream text fields, the violet
gradient main button, gold stars, and the private-feedback link as an underlined
link instead of a second button.

What it does **not** change: any markup, any behaviour, any dashboard page. The
QR slug, five stars, ≤3 topics, the 600-character box, the language picker, the
AI drafts, the private feedback form, the Google link and the wheel are all the
same code. No new fonts, no CDN, no image files — the glows are CSS gradients.

The dashboard keeps its own palette; this file is never loaded there
(`verify-assets` still reports 0 diffs on the homepage and dashboard).

## Reference-matched finish (`customer-reference.css`)

The last visual layer, loaded only by `review.php`, retunes the page to the
approved reference screenshot:

| Token | Value |
|---|---|
| page background | `#FFF9F0` |
| card background | `#FFFCF7` (92% opaque, blurred) |
| primary purple | `#6529ED` |
| secondary purple | `#9B5CFF` |
| lavender | `#F2E8FF` |
| border | `#E9D8FA` |
| main text | `#17164F` |
| secondary text | `#645A99` |
| stars | `#FFAC21` |

- **Background:** cream page, purple circle in the bottom-left corner, lavender
  circle in the top-right corner, faint diagonal wash, ambient glow behind the
  card and a slowly drifting sparkle layer. All CSS + one inline SVG, no images,
  no CDN, `pointer-events: none`.
- **Card:** 460 px wide, 35 px radius, thin lavender border, soft purple glow,
  fade-and-rise entrance. On phones it fills the width instead.
- **Header:** back arrow, purple sparkle + **ReviewAI** wordmark centred; the
  business name stays in its own lavender pill below, straight from the database.
- **Type:** 34 px navy heading on desktop, 28 px on phones.
- **Stars:** 44 px, gold `#FFAC21` when chosen, lavender outline when not, hover
  lift and a small pop on selection.
- **Chips:** soft white/lavender, selected chips take the purple gradient with a
  check mark; the count and the helper sentence update live.
- **Button:** 48 px pill, `#6529ED → #9B5CFF`, lift on hover, press on click,
  sparkle prefix, disabled state stays quiet.
- **Wheel:** violet/cream wedges, gold rim, purple centre badge, "Spin the
  **Wheel!**" with the second word in gradient — matching the second reference
  image. A locked wheel stays in colour; only the button says it is waiting.
- **Motion:** honour `prefers-reduced-motion` — the card, logo, sparkle drift and
  all transitions switch off.

Copy now matches the brief: rating messages ("We're sorry. What went wrong?" …
"Excellent! What did you love?"), "What stood out? (pick up to 3)", the
"0 of 3 selected…" helper, and "The draft is written from the topics you pick…".

---

## Final polish pass (buttons and UI/UX review)

The page was reviewed in a real browser at 320, 390, 768 and 1280 px, every
control was pressed, and the visual layer was rewritten as **one** stylesheet
instead of the six stacked override layers the page had accumulated. Nothing
about the flow, the ids, the classes the JavaScript uses, or the backend calls
changed — this is shape, colour, spacing, type and motion.

### Worst bugs found and fixed

| Problem | Cause | Fix |
|---|---|---|
| The **globe** button did nothing | it scrolled to the language row, which is inside step 2 and therefore hidden until a star is picked | it now moves to the rating block and says *"Pick a star first — the draft language is on the next step."* |
| The locked wheel had **no Spin button at all** | `customer-wheel.css` hid `.rg-wheel-spin` while locked | the button is shown and **disabled** (the brief asks for a disabled button, not a missing one), in a light lilac state |
| The Spin hub could not be centred | `.rg-wheel-spin` carries `margin-top: 14px` while the hub is absolutely positioned | `margin: 0` — the test now measures `dx 0 / dy 0` |
| The hub turned into a **bar** across the wheel | it is also a `.main-button`, which asks for `width: 100%` | id-scoped circle, 92 × 92, always on top of the wedge artwork |
| The "go to Google" block laid out sideways | `.rg-direct` is a column (link, "or", privacy line) but was styled as a row | column layout; the button keeps one line |
| The privacy line had a stray empty box | an earlier layer gave `.rg-privacy` a border and background with no padding | plain centred text |
| The terms row printed **two** arrows | markup arrow plus `summary::after` chevron | the chevron from the older layer is removed; the markup arrow rotates when open |
| Social chips stacked icon-over-label and wrapped unevenly | `.rg-social-btn` kept `flex-direction: column` | a row inside each chip; a 2-column grid on phones, 4 across from 560 px, odd last chip centred |
| The step rail clipped "Topics" | fixed padding plus `nowrap` | equal thirds, smaller type, and under 360 px the number circles step aside |
| On a 320 px phone the **Share QR** pill was cut off by the card edge | header had no small-phone rule | under 360 px it becomes a 40 px icon button (same `aria-label`) |
| The chosen wheel was greyed out after the spin | `.is-done` faded the disc | the wedges stay in colour; the result panel carries the news |

### The look, in the official palette

| Token | Value | Used for |
|---|---|---|
| cream | `#FBF8F2` | page |
| off-white | `#FFFDFB` | card |
| purple | `#4B20DC` | primary, active steps, buttons |
| navy | `#141623` | headings and body ink |
| lavender | `#F1EBFE` | pills, kicker, coupon panel |
| lime | `#E7F3B7` | reserved highlight token |
| gold | `#E9B44C` | wheel rim and pointer |
| star | `#F5B301` | a chosen rating |

- Header: 40 px circular back button with a drawn chevron, sparkle + **ReviewAI**,
  globe, purple gradient **Share QR**.
- Profile: soft lavender halo, a thin arc, 88 px logo disc (business logo, else the
  business initial), business name in a lavender pill.
- Stars: 46 px (50 px from 820 px), lavender outline, gold with a pop when chosen.
- Wheel: gold rim, violet/cream alternating wedges that read tangentially, fixed gold
  pointer with a white notch, 92 px gradient hub with a breathing ring when the spin
  is available.
- Prize panel: coupon in a dashed lavender panel with a solid **Copy coupon** button,
  then discount / valid-until / business, then the redemption note.
- Motion: logo rise, drifting sparkles, star pop, hub pulse, toast slide; everything
  is switched off under `prefers-reduced-motion`.

### New checks (13, in `tools/test-review-flow.mjs`)

* the locked wheel shows a **disabled** spin button, sized as a circle and visible;
* the lock note still reads *"Your spin unlocks after you submit your review."*;
* the back control draws an SVG arrow, not a character;
* **Share QR** answers with a confirmation;
* the globe either moves the page or explains itself — never nothing;
* every configured link renders, no label wraps, every chip is at least 44 px tall,
  every chip opens in a new tab, and none is a dead link.

`node tools/test-review-flow.mjs` → **179/179**.

### Second pass — the spin, and the links dock

Two things a customer reported: *"the wheel isn't spinning"* and *"the Instagram /
Facebook buttons are not in sequence"*.

| Problem | Cause | Fix |
|---|---|---|
| The wheel appeared not to spin | the turn was a **CSS transition**. A browser or an OS setting that shortens transitions (`prefers-reduced-motion`, some Android batteries savers, an interrupted transition) turned 4.6 seconds into one frame — the prize appeared, the wheel never turned | the rotation is now drawn by a `requestAnimationFrame` loop with an ease-out curve: 5 turns, fast start, long settle, always ends exactly on the awarded wedge. Reduced motion still gets a real — shorter (700 ms) — spin instead of a snap |
| Tapping the locked wheel said nothing | the centre button is `disabled`, and a disabled button fires no click at all | while locked the hub steps out of the way (`pointer-events: none`, it is inert anyway) and the stage behind it answers: *"Finish your review to unlock the wheel."* Copying the old "tap the wheel" habit, tapping the wedges **when it is ready now spins it**, and tapping after the spin repeats that the spin was used |
| The links were an uneven 3 + 2 grid and never in a fixed sequence | they were boxy chips in an auto-fit grid | a **floating dock**: one row, one round glass button per configured link in the owner's order (Google, Instagram, Website, WhatsApp, Facebook…), the brand mark inside, the name underneath, each one bobbing 3 px on its own beat. Five links fit at 320 px; more would scroll, never wrap |

New checks (4): tapping the locked wheel explains itself and leaves the button
disabled; every link sits in one ordered row; each is a round floating button; the
sequence matches the configured order — plus the existing "the disc physically
rotates" and "the disc never jumps backwards" now measure the frame loop
(335 frames, 1980° in the last run).

`node tools/test-review-flow.mjs` → **183/183**.
