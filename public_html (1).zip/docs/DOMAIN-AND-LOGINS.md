# Domains, logins, and what page is which

Plain-English answer to: *where does the site live, how do I get into the admin
panel, how does a client log in, and what is the home page?*

Read §1–§2 once to get the mental model. §4 is the actual click-by-click for going
live on Hostinger. Everything here matches the code that ships in `app/`.

---

## 1. What you are actually running

Three pieces, nothing more:

| Piece | What it is | Where it lives |
|---|---|---|
| The **code** | PHP files in `app/` | `public_html/` on the hosting |
| The **database** | one MySQL database, 10 tables | created in hPanel → MySQL Databases |
| The **domain** | the name people type | pointed at the hosting by nameservers |

No Node, no build step, no cloud backend. (Supabase is **not** used by this app —
it talks to MySQL directly. If Supabase is connected to this chat, ignore it; you
do not need it to run or host this.)

One domain runs everything. There is no separate "admin domain" and no separate
"client domain" — the same domain serves the marketing home page, both logins, the
dashboards, and the customer QR page.

---

## 2. The map — which URL is which

Example domain used below: **`shop.com`**. Replace it with yours.

| Who opens it | URL | Login needed? | What it is |
|---|---|---|---|
| Anyone on the internet | `https://shop.com/` | no | **The home page.** Marketing/landing page (`index.php` → `home.php`): hero, how it works, features, pricing, FAQ, *Sign in* and *Get started* buttons |
| A **business (your client)** | `https://shop.com/signup` | — | Create an account (also reachable as `/register`) |
| A client, returning | `https://shop.com/login` | yes | The **one login page**. A client lands on `dashboard.php` |
| A client, signed in | `https://shop.com/dashboard` | yes | Their cards, totals, links |
| **You, the admin** | `https://shop.com/login` then `owner.php` | yes | Same login form; the owner email is redirected to `/owner.php` |
| A **customer** with a phone | `https://shop.com/r/mystore/` | no | The review page from the QR code |
| First-time setup only | `https://shop.com/install.php` | — | The 4-step installer. **Delete it afterwards.** |

Two things worth burning into memory:

1. **There is exactly one login page** (`/login`). The app looks at *which email*
   signed in and decides where you land: the owner email → admin panel, everyone
   else → client dashboard. You never type a different URL for the admin panel.
2. **There is exactly one admin account**, identified by the email stored in the
   setting `owner_email`. It is not a role column, so there is no "promote this
   user to admin" button. To move admin to another person you change
   `owner_email` (in `config.php` **and** Owner panel → Settings) to their email
   and make sure that email has an account.

---

## 3. The three "home" pages (people confuse these)

| Question you are asking | Page |
|---|---|
| "What does a stranger see at `shop.com`?" | the **marketing home page** — `index.php` → `home.php` |
| "What does a business see after logging in?" | the **client dashboard** — `dashboard.php` |
| "What does a paying customer see after scanning the QR?" | the **review page** — `/r/<slug>/` (`review.php`) |
| "What do I see as the site operator?" | the **admin panel** — `owner.php` |

The marketing home page contains no business data; it is a shop window. Business
name, logo and colours appear on `/r/<slug>/`, and they come from that card in the
database, never from the page source.

---

## 4. Going live: domain → working site (Hostinger)

Work top to bottom. Each step ends with a check.

### 4.1 Get the domain pointing at the hosting

- **Bought at Hostinger?** Nothing to do — it is already on Hostinger's
  nameservers. Skip to 4.2.
- **Bought at GoDaddy / Namecheap / BigRock etc.?** In the Hostinger hPanel open
  **Domains → (your domain) → Nameservers**, copy the two nameserver values shown
  there (they look like `ns1.…` / `ns2.…`), then paste those two values into your
  registrar's nameserver settings. Save.

**Check:** `whois`/`dnschecker.org` for your domain shows the Hostinger
nameservers. Propagation is usually 10 minutes, worst case a few hours. You can
upload the files while you wait.

### 4.2 Create the site in hPanel

**Websites → Add website → Existing domain** → type `shop.com` → choose **Empty
site / PHP**. This creates `public_html`.

> **Subfolder instead?** If you want the app at `shop.com/review` rather than the
> root, upload into `public_html/review` instead. The app detects its own base
> path, so `/review/login`, `/review/dashboard` and `/review/r/<slug>/` all work.
> Then the installer URL becomes `shop.com/review/install.php`. Pick one layout
> **before** you print any QR codes and do not change it later.

### 4.3 Upload the files

File Manager (or FTP/SFTP) → open `public_html` → upload the **contents of the
`app/` folder**, so that `public_html` itself contains `index.php`, `login.php`,
`dashboard.php`, `owner.php`, `review.php`, `install.php`, `includes/`, `assets/`,
`.htaccess`, and so on.

- **Do not** upload `tools/`, `tests/`, `docs/`, `dev/`, `frontend/`, or the ZIP.
- Folders `755`, files `644`. `assets/uploads/` must be writable (logos).
- The `.htaccess` file is what makes `/login`, `/dashboard` and `/r/<slug>/` work
  instead of `/login.php`. Make sure your FTP client copied it (hidden files!).

**Check:** visiting `https://shop.com/` gives the installer, not a 500 and not a
directory listing.

### 4.4 Create the database

hPanel → **Databases → MySQL Databases**:

1. Database name → Hostinger prefixes it, e.g. `u123456789_reviewgrow`.
2. Create a user with a long random password.
3. **Add user to database → All privileges.**

Write the three values down (`localhost`, db name, user, password) — the
installer asks once.

### 4.5 Run the installer

Open `https://shop.com/install.php`. Four steps: **Welcome → Database → Owner
account → Done**. Step 3 is where you create **your admin account** — use a real
mailbox you control, because that email becomes the one and only admin.

**Check:** you are bounced to `/login`. Sign in. You are inside `owner.php`
(the admin panel). Then **delete `install.php`** — File Manager → select →
delete. The app refuses to re-run it once an owner exists, but delete it anyway.

### 4.6 Turn on HTTPS

hPanel → **Security → SSL** → install the free certificate for `shop.com` (and
`www.shop.com`). Then **Websites → Advanced → Force HTTPS** = on.

HTTPS is not cosmetic here: the customer page copies review text to the clipboard
and opens Google review links, and both behave badly on an `http://` origin. Also,
a QR code pointing at `http://` shows a warning on many phones.

### 4.7 Tell the app its own address

Admin panel → **Settings**:

| Setting | Value |
|---|---|
| App name | what appears in the browser tab and header, e.g. *ReviewAI* |
| **Site URL** | `https://shop.com` — **this is what the QR codes will encode** |
| GROQ API key (optional) | switches AI draft writing on |
| WhatsApp number (optional) | the fallback "pay via WhatsApp" button |

If Site URL is blank the app guesses from the current request, which works but can
bake in `http://` or a `www.` you did not intend. Set it explicitly before you
print anything.

### 4.8 Pick one hostname and stay on it

Decide now: `shop.com` (recommended) or `www.shop.com`. In hPanel create a
redirect for the one you are **not** using, so both spellings land on the same
place. A QR code printed with `www.` will 301 to the bare domain and still work,
but the reverse confuses some scanners — so keep it consistent.

### 4.9 Final check

- `https://shop.com/` → home page, padlock, no `www` mismatch
- `https://shop.com/login` → login form
- sign in → `/owner.php` → your admin panel
- `https://shop.com/install.php` → gone (404 or blocked)

---

## 5. Logging in as the admin (you)

- URL: `https://shop.com/login` — the ordinary login page.
- Email: the one you typed in installer step 3.
- Password: the one you chose there.
- Land on: `owner.php`.

From the admin panel:

| Menu | File | What it controls |
|---|---|---|
| Dashboard | `owner.php` | totals across all businesses |
| Businesses / cards | `owner_cards.php` | every review card, every customer link |
| Users | `owner_users.php` | every account (read-only by design — no ban/edit backend exists) |
| Plans | `owner_plans.php` | the plans and prices shown on the home page and to clients |
| Settings | `owner_settings.php` | app name, Site URL, AI key, WhatsApp, payments |
| Marketing | `owner_marketing.php` | the popup manager |
| Home page | `owner_homepage.php` | the video block on the landing page |

**If you forget the password:** there is no "forgot password" email in this app
(no mailer is wired). Reset it in phpMyAdmin instead — generate a hash on any
machine with PHP:

```bash
php -r "echo password_hash('MyNewPass123', PASSWORD_DEFAULT), PHP_EOL;"
```

then in phpMyAdmin → your database → `users` table → find your row → edit
`password` → paste the hash → Save. Sign in normally.

**If you change your admin email**, remember it lives in two places:
`config.php` (`'owner_email' => ...`) and the `settings` table. Change both, or
the panel will bounce you to the client dashboard.

---

## 6. How a client (business owner) gets in

1. **Sign up** — `https://shop.com/signup`. Only email + password; there is no
   name field because the `users` table has no name column.
2. **Create their first card** — straight after signing up the app sends them to
   `/onboard`, where they enter business name, logo (optional), Google review
   link, and pick a slug. That slug becomes their permanent public address:
   `https://shop.com/r/<slug>/`.
3. **Land on `/dashboard`** — their cards, review counts, and buttons to each card.
4. **Returning visits** — `https://shop.com/login` → `/dashboard` automatically.

Inside a card (`card_home.php?slug=…` and the menu):

| Page | Purpose |
|---|---|
| `card_home.php?slug=…` | the card's public link + the **QR code** (drawn in the browser, downloadable, no third-party QR service) |
| `card_reviews.php?slug=…` | reviews collected, filter by rating, private feedback inbox |
| `card_wheel.php?slug=…` | spin-the-wheel prizes, stock and odds |
| `card_membership.php?slug=…` | plan, trial days left, upgrade buttons |
| `card_settings.php?slug=…` | business name, logo, Google link, social links shown on the review page |
| `card_payments.php` | payment history |

**Billing:** a new card starts on a **trial**. Plans are created by you in
**Owner → Plans**; a client pays through Razorpay (once you add keys) or taps
"Pay via WhatsApp" and you activate the plan manually. Payments stay off until
you add keys and choose a mode — see `CONFIGURATION.md` §5.

---

## 7. What the customer does (no account at all)

They scan the QR → `https://shop.com/r/<slug>/`:

1. Five stars → 4–5 stars continues to the AI draft flow; 1–3 stars offers the
   private feedback form.
2. They edit the draft, copy it, and continue to the business's Google review page
   themselves. **The app never posts to Google for them.**
3. If the business enabled the wheel, submitting private feedback unlocks **one**
   spin, tied to that customer's browser + participation token, enforced on the
   server.

The customer never sees a login, an email field, or the admin panel.

---

## 8. Things that trip people up

| Symptom | Cause |
|---|---|
| `/login` 404s | `.htaccess` was not uploaded (hidden file), or mod_rewrite is off. `login.php` still works as a fallback |
| QR opens `http://` or the wrong host | Site URL not set in **Settings** — set it, then re-download the QR |
| QR works for you, not for customers | You printed it while the domain was still on the temporary hostname, or the domain was changed later. Reprint after the domain is final |
| Client signs in and sees the admin panel | Their email equals `owner_email`. Use a different address for clients |
| Client cannot see the admin panel | Correct — one admin, by design |
| Uploaded the whole ZIP folder | The files must sit **directly** in `public_html`, not in `public_html/reviewgrow-php/app/` |
| Blank page / 500 after upload | Wrong PHP version (need 8.1+), or `config.php` missing → run the installer |
| Logos fail to upload | `assets/uploads/` not writable (755 and owned by your user) |
| Changing the domain later | Update **Site URL**, then reprint every QR. Old printed codes are dead |

---

## 9. Launch checklist

- [ ] Domain nameservers point at the hosting; `shop.com` resolves
- [ ] Website created, files directly in `public_html`, `.htaccess` included
- [ ] MySQL database + user with all privileges
- [ ] `install.php` completed; **your** admin email used
- [ ] `install.php` deleted
- [ ] SSL installed, Force HTTPS on
- [ ] Settings → App name, **Site URL**, (optional) AI key, WhatsApp number
- [ ] One hostname chosen; the other redirects to it
- [ ] Owner → Plans filled in (empty plans = an empty pricing section)
- [ ] A test client account signs up, creates a card, QR opens on a real phone
- [ ] A test customer runs 5 stars → draft → Google, and 2 stars → feedback → wheel
- [ ] Backups scheduled (hPanel → Files → Backups)
