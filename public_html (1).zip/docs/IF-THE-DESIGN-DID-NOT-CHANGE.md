# "I uploaded it and nothing changed" — 6 checks, in order

This is for exactly one symptom: **you replaced the files and the customer page
still looks the same.** Work down the list; it is ordered by how often each cause
is the real one.

Example site used below: `https://shop.com` — use yours.

---

## Check 0 — are you looking at the *live site*, or at a file on your laptop?

The customer page is PHP. It cannot be opened by double-clicking `review.php` on
your computer: you get raw code, a blank page, or a download prompt, and it never
looks like the design. It only renders when a PHP server runs it.

**Open:** `https://shop.com/r/<your-slug>/` — from the hosting, in a browser.

If you do not have a slug yet: sign in, open a card, and the dashboard shows
`/r/<slug>/`. If the site is not deployed at all, run the installer first
(`docs/DOMAIN-AND-LOGINS.md` §4).

---

## Check 1 — did the files actually land where the site reads them?

File Manager → open `public_html`. It must contain **`index.php`, `login.php`,
`dashboard.php`, `owner.php`, `review.php`, `includes/`, `assets/`, `.htaccess`**
directly — not inside `public_html/last-day/`, not inside
`public_html/app/`, not inside `public_html/reviewgrow-php/app/`.

The classic mistake: you upload `last-day.zip`, use "Extract", and the host
creates `public_html/last-day/` with everything inside it. The domain keeps
serving the old copy that was already at the top level.

**Check:** `https://shop.com/assets/css/customer-reference.css` opens a real CSS
file (about 35 KB). If it 404s, the CSS folder was not uploaded.

---

## Check 2 — is the browser showing you a cached stylesheet?

This was a real bug in the app, now fixed, and it is the most common reason a
deploy "does nothing":

| Before | Now |
|---|---|
| every page linked `assets/css/customer-reference.css` — the **same URL forever**, so the browser and any caching proxy (LiteSpeed on Hostinger, phones, Safari) kept serving the copy they downloaded the first time | the URL carries the file's modification time: `…customer-reference.css?v=1762000000`, so a changed file is a new URL and the old copy can never be reused |

The customer page also now sends `Cache-Control: no-store` so the HTML itself is
never served stale.

**If you tested an older build**, hard-reload once and it will pick the new files:

- Desktop: `Ctrl + Shift + R` (Windows) / `Cmd + Shift + R` (Mac), or use a
  **private/incognito window**.
- Phone: close the tab, reopen, or clear site data for the domain.
- Hostinger: hPanel → **Advanced → LiteSpeed Cache** → *Purge All* (only if that
  cache is actually on).

---

## Check 2b — the one-page answer: `/rg-build-check.php`

Fastest possible check, no dev tools: open

```
https://shop.com/rg-build-check.php
```

It prints three blocks of text, e.g.

```
review.php ................ found, 2026-11-04 14:31
  wheel really spins ...... YES
  floating links markup ... YES
  build stamp present ..... YES

customer-reference.css .... found, 2026-11-04 14:31, 35,343 bytes
  floating dock styles .... YES

config.php ................ present
  database ............... connected (server 10.6.18-MariaDB)
```

- all **YES** → the server has the new build. Any remaining stale look is the
  browser or a proxy (Check 2).
- **NO** on a line → that exact file on the server is old; upload it again.
- **MISSING** on `review.php` → the files are not in `public_html` at all; they
  are probably one folder down (Check 1).

Delete `rg-build-check.php` when you are done — it is a diagnostic, not part of
the product, and it prints nothing secret (no paths, no passwords, no customer
data).

---

## Check 3 — is the server running the new `review.php`? (10 seconds)

The page now stamps itself. Open the customer page, then **view source**
(`Ctrl + U`, or on a phone: `view-source:https://shop.com/r/slug/`) and search
for **`rg-build`**:

```html
<meta name="rg-build" content="2026-11-04 14:31 · 1762000000">
<!-- ReviewGrow customer page · design layer customer-reference.css @ 2026-11-04 14:31 · 1762000000 -->
```

| What you see | What it means |
|---|---|
| a date + number | ✅ the new `review.php` is live on that domain |
| `content="unknown"` | the new file is live but it cannot read the CSS file — the stylesheet is missing from `assets/css/` |
| no `rg-build` line at all | ❌ the browser is still on an **old `review.php`** → the upload went to the wrong folder (Check 1) or a cache is in front (Check 2) |

---

## Check 4 — is the stylesheet linked *after* the older layers?

The customer page is styled by six layers, and the new design is the **last** one,
so it must win. In view source the order must be:

```html
<link … customer.css>
<link … customer-premium.css>
<link … customer-refresh.css>
<link … customer-wheel.css>
<link … customer-cream.css>
<link … customer-reference.css?v=…
```

If `customer-reference.css` is not there at all, you are on an old `review.php`
(Check 3). If it is there but the page looks old, the file itself is old — open
`https://shop.com/assets/css/customer-reference.css?v=1` and search for
`rg-float`; it must be present.

---

## Check 5 — is that exact URL a real, live card?

| What you see | Cause |
|---|---|
| A plain **"Page Not Found"** page | the slug is wrong or the card was deleted. That page is intentionally bare and old-looking |
| The page shows an unrelated business name | you are on a different card than you think |
| The page shows the old cream/green design with square links | old `review.php` (Check 3) or old CSS (Check 2) |

---

## What "the new design" actually looks like

So you can tell at a glance whether the deploy took:

1. **Cream page** (`#FBF8F2`) with one big rounded white card, soft shadow, tiny
   sparkles.
2. Business **logo + name** at the top — the logo comes from the card, never a
   hardcoded image. No logo uploaded → the business's initials in a purple circle.
3. Heading **"How was your experience?"**, then **five large stars**, then
   "Go directly to Google →".
4. A **floating row of round brand buttons** — Google, Instagram, Website,
   WhatsApp, Facebook — only the ones the business configured, each bobbing
   gently, name underneath.
5. Then the **"Spin the Wheel!"** card with a gold pointer, purple/lavender/cream
   wedges, and a purple spin button in the middle. Locked until feedback is sent;
   tapping the grey wheel says so.
6. Footer privacy line.

If you see **square link tiles in a 3 + 2 arrangement**, that is the pre-dock
build: the CSS is old (Check 2/4). If the wheel jumps straight to the prize
instead of turning for ~4 seconds, the **JavaScript is old** (Check 3).

---

## Still stuck? Send these three things

1. The exact URL you opened.
2. The line that appears when you search the page source for `rg-build`.
3. What `https://shop.com/assets/css/customer-reference.css?v=1` shows — the
   first line of it, or a 404.

Those three answers say whether it is the upload, the cache, or the card.
