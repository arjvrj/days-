# ReviewGrow

A PHP + MySQL SaaS that lets a local business collect Google reviews: a customer
scans a QR code, answers a couple of questions, gets an AI-written draft they can
edit and copy, and is sent to the business's Google review page. 1–3 star
customers are offered a private feedback form instead. Business owners get a
dashboard; the site owner gets an admin panel; paid plans are sold through
Razorpay with a WhatsApp fallback.

**Version:** final-source-code-v1 (all seven stages)
**Requirements:** PHP 8.1+ with `pdo_mysql`, `curl`, `json`, `openssl`; MySQL 5.7+ / MariaDB 10.2+
**Install guide:** `INSTALL.md` · **Go-live checklist:** `HOSTINGER-DEPLOYMENT.md` · **Settings:** `CONFIGURATION.md`

---

## What is in the box

```
app/                     ← this folder is what goes into public_html
  *.php                  40 PHP files: pages, endpoints, installer
  includes/              db, auth, security (CSRF), payments, payment_flow,
                         functions, layouts (public, dashboard, owner, card)
  assets/css/            design stylesheets + built bundles (fonts vendored)
  assets/js/             dashboard.js + vendored libraries
  fonts/                 DM Sans, Inter, Noto Sans Devanagari/Telugu (self-hosted)
  assets/vendor/         Font Awesome 6 (self-hosted)
  assets/uploads/        business logos (writable, execution blocked)
  .htaccess              clean URLs, hardening, block rules
  config.example.php     copy to config.php if you do not use the installer

sql/
  schema.sql             complete fresh-install schema (10 tables)
  migrations/
    2026-11-payments.sql Stage 7 additions for an existing database
  seed-demo.sql          OPTIONAL demo data for clicking through the UI locally
                         (never import it on a live site — it contains demo logins)

docs/                    the report for every stage (0–7)
tools/  tests/  dev/tailwind/
                         the test suite + the Tailwind build config
                         (NOT part of the running site)
```

## The three roles

| Role | Where | How they get in |
|---|---|---|
| Customer | `/r/<slug>/` | no account — scans a QR code |
| Business owner | `/dashboard/` | signs up, creates a review card |
| Site owner (admin) | `/owner.php` | the first account created by the installer |

The admin is identified by the `owner_email` setting rather than a role column:
that account is the only one that reaches `owner.php`. There is exactly one admin
by design (see `docs/STAGE-5-ADMIN.md` §9).

## Quick start (local)

1. Create a MySQL database.
2. Point your web server's document root at `app/`.
3. Open `/install.php`, follow four steps: welcome → database → owner account → done.
4. **Delete `install.php`.**
5. Sign in, add the GROQ API key in **Owner panel → Settings** to switch AI review
   generation on.
6. Add plans in **Owner panel → Plans**; they are what customers see on the
   membership page.

Payments are **off** until you add Razorpay keys and choose a mode
(`CONFIGURATION.md` §5).

## Tests

The suite lives in `tools/` and `tests/` and needs Node 20 plus Playwright
(browser suites only). It never goes on the server.
It is never uploaded to the server.

```bash
cd dev
node tools/php-lint.mjs app                       # 40/40 files parse
node tools/test-security.mjs                      # 116 wiring checks
node tools/check-links.mjs                        # assets resolve, no CDN requests
node tools/check-schema.mjs                       # schema.sql matches install.php
node tools/check-install-css.mjs                  # install.php classes are all styled
node tools/check-seed.mjs                         # seed-demo.sql matches the schema
node tools/php-run.mjs tests/php/test_payments.php  --require app/includes/payments.php
node tools/php-run.mjs tests/php/test_orders.php    --require app/includes/payments.php --require app/includes/payment_flow.php
node tools/php-run.mjs tests/php/test_security.php  --require app/includes/security.php
node tools/php-run.mjs tests/php/test_home_video.php \
  --require app/includes/payments.php --require app/includes/ai.php \
  --require app/includes/links.php --require app/includes/functions.php \
  --require app/includes/home_video.php             # 111 homepage video checks
node tools/test-home-video.mjs                      # 78 browser checks
node tools/php-run.mjs tests/php/test_popups.php \
  --require app/includes/payments.php --require app/includes/ai.php \
  --require app/includes/links.php --require app/includes/functions.php \
  --require app/includes/popups.php                 # 98 popup checks
node tools/test-popups.mjs                          # 96 browser checks
```

`docs/FINAL-DELIVERY.md` lists every suite, its result, and every known gap.
`docs/HOMEPAGE-VIDEO.md` explains the demo video section and its owner page.
`docs/POPUP-MANAGER.md` explains the promotion popup manager under
Marketing → Popup & Promotions: the campaign list, the editor, the four layouts, the
triggers, frequencies and page targeting, and the pages a popup can never appear on.
`docs/STAGE-7-PAYMENTS.md` §3 explains each payment case.

## Licence and provenance

The backend logic is the purchased ReviewGrow application, kept as the source of
truth and hardened stage by stage. The interface follows the original ReviewGrow
design system. Every change is recorded in `docs/` and in the git history
(`git log --oneline`).
