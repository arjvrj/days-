# Start here

This ZIP is the ReviewAI application, ready to upload. It contains the whole site
— the public marketing pages, the owner/admin panel, the business dashboard, the
customer QR review page with the spin-the-wheel reward, the demo video section and
the popup & promotion manager.

Two ways to use it:

* **I have never installed ReviewAI** → follow *First install*.
* **ReviewAI is already running** → follow *Upgrade an existing site*.

Read `INSTALL.md` for the full installer walkthrough and `HOSTINGER-DEPLOYMENT.md`
for the exact Hostinger steps (upload, PHP version, cron, SSL). This page is the
short version.

---

## 1. Get the files into `public_html`

1. In hPanel open **Files → File Manager** and go to `public_html`.
2. Upload the ZIP, then use **Extract** on it.
3. The archive has **no wrapper folder**: after extracting, `public_html` must
   contain `index.php`, `install.php`, `.htaccess`, `includes/`, `assets/`,
   `fonts/`, `sql/` and `docs/` directly. If you see one folder with those names
   inside it, move its contents up one level.
4. Delete the ZIP from the server once it is extracted.

The `.htaccess` file must be present. It blocks direct access to `config.php`,
`sql/` and the docs, and it is what makes the clean URLs work.

## 2. First install

1. Visit `https://yourdomain.com/install.php`.
2. The installer checks the server (PHP 8.1+, PDO MySQL, the required extensions),
   then asks for the database details: host, name, user, password (all from
   **hPanel → Databases → MySQL Databases**).
3. It writes `config.php`, creates all 16 tables, seeds the plans and the payment
   settings, and then **refuses to run twice** — that is deliberate.
4. Log in with the email and password you set on the last installer screen.
5. Delete `install.php` afterwards, as the installer says.

## 3. Upgrade an existing site

1. Take a database backup first (**hPanel → Files → Backups**, or export the
   database in phpMyAdmin).
2. Upload and extract over the existing files, keeping `config.php`.
3. Run the migrations in `sql/migrations/` **in date order**, once each, in
   phpMyAdmin (SQL tab). The newest one is named after the feature it adds, for
   example `2026-11-popups.sql`.
4. Open the panel: **Owner panel → Homepage** (demo video) and **Marketing →
   Popup & Promotions** (promotions) are the two newest screens.
5. Nothing else needs to be done: there is no build step, no `npm install` and no
   compiled assets on the server.

## 4. What to check after installing

| Check | Where |
|---|---|
| Homepage loads, demo video section plays or shows its poster | `/` |
| Plans and prices are the ones you configured | `/` and **Owner panel → Plans** |
| Signup, log in, business dashboard | `/signup.php`, `/login.php`, `/dashboard.php` |
| A review card opens and the wheel unlocks after feedback | `/r/<card-slug>` |
| A popup can be created and previewed | **Owner panel → Marketing** |
| The AI writer answers (needs the API key in the panel) | **Owner panel → Settings** |

## 5. Things that need your own details

* The **AI provider key** — set it in the owner panel. Without it the writer shows
  its honest failure state; nothing else breaks.
* The **payment provider** — it ships disabled. Enable it in the owner panel when
  you have the live keys.
* A business's **Google review link**, social links and logo — each business sets
  these in its own dashboard, which is why no business name or link is hardcoded
  anywhere in the code.

## 6. If something looks wrong

1. `https://yourdomain.com/install.php` — if it still opens, the install never
   finished; run it again.
2. PHP version must be 8.1 or newer (**hPanel → Advanced → PHP Configuration**).
3. A 500 error usually means `config.php` is missing or has the wrong database
   password.
4. `docs/FINAL-DELIVERY.md` lists every test suite and every known gap, and
   `docs/` explains each feature in plain English.

Nothing in this package talks to any server except your own. There are no CDN
requests, no external fonts and no tracking scripts.
