# The wheel stays locked after picking a draft — a decision tree

Symptom: drafts are on screen, the customer taps one, and the centre button is
still grey (or nothing happens at all).

Pick the branch that matches what is *actually* on your server. Example site:
`https://shop.com`.

---

## Step 1 — does the page on the server know how to unlock?

Open:

```
https://shop.com/rg-build-check.php
```

Look at these three lines:

```
review.php ................ found, 2026-11-04 14:31
  wheel really spins ...... YES
  floating links markup ... YES
```

Then these, added for the wheel:

```
  pick-a-draft endpoint ... YES
  unlock safety copy ...... YES (unlocks even with an older wheel.php)
  includes/wheel.php ...... current
```

| Result | Meaning |
|---|---|
| `pick-a-draft endpoint ... NO` | the `review.php` on the server is **older than this build**. It has no `action=choose`, so picking a draft sends a request the page does not understand and nothing happens. Upload this build's `review.php` (and `includes/wheel.php`) |
| `pick-a-draft endpoint ... NO` | the `review.php` on the server is older than this build — nothing can unlock. Upload this build's `review.php` |
| `includes/wheel.php ... OLD` and `unlock safety copy ... YES` | a **mixed upload**: `review.php` is new, `includes/wheel.php` is not. The safety copy makes it work anyway; upload `includes/wheel.php` when convenient |
| all `YES` / `current` | the files are current — go to Step 2 |

---

## Step 2 — is the campaign actually able to unlock anyone?

Add the slug of the card you are testing:

```
https://shop.com/rg-build-check.php?slug=your-slug
```

```
Wheel for /r/your-slug/
  card .................... found: Tribe Fitness
  card active ............. YES
  campaign ................ id 1, enabled YES, starts any time, ends never
  open right now .......... YES
  prize odds .............. YES (7 prizes)
  this browser's spin ..... not granted yet
  this browser eligible ... NO
```

| Line that says | What to do |
|---|---|
| `campaign ... NONE` | the wheel was never saved for this card. Open the card → **Spin the Wheel** in the dashboard, set the prizes, press Save |
| `enabled NO` | switch the campaign on |
| `open right now ... NO` | the campaign's start/end dates are in the past. Fix the dates in the dashboard |
| `prize odds ... NO` | the prize percentages do not add up to exactly 100%; the server refuses to run a wheel that pays out more or less than it should. Fix the odds (or press *Restore default odds*) |
| `card active NO` | the card's membership expired — nothing on the customer page works, not just the wheel |
| everything YES | go to Step 3 |

---

## Step 3 — what does the page itself say?

On the customer page, pick a draft and watch the line under the wheel:

| What you see under the wheel | Meaning |
|---|---|
| *"Your free spin is ready!"* + the button turns on | it worked |
| ⚠️ *"Your spin could not be unlocked just now…"* | the request reached the server and the server refused **or** the request failed. The browser console (F12 → Console) now prints the exact reason: `[ReviewGrow] spin unlock failed: …` |
| the locked sentence never changes | the tap never reached the card. This build listens on three routes (card tap, radio change, focusing the draft text) precisely because iOS Safari skips the first one |

---

## Step 4 — the two mistakes that look like a broken wheel

1. **Testing on a second browser or a different phone mid-flow.** One spin per
   *customer* is enforced per browser (a participation row bound to a secure
   cookie + IP hash). A customer who already spun on their phone will see
   *"This spin has been used"* on that phone and a *fresh, unlocked* wheel on a
   different one. `rg-build-check.php?slug=…` prints `this browser's spin` so you
   can see whose spin you are looking at.
2. **Refreshing the page after picking a draft.** That is fine — the state is in
   the database, so the wheel comes back unlocked. If it comes back **locked**
   after a refresh, the server never recorded the pick, which means the request
   failed (Step 3) or the file is old (Step 1).

---

## What changed in this build (so you know what to look for)

| Before | Now |
|---|---|
| Only a tap on the draft card selected it | card tap **or** radio change **or** focusing the draft text — one of the three works on every phone |
| A failed unlock did nothing at all (grey wheel, no message) | a visible line under the wheel, a toast, and the exact reason in the console |
| Tapping the grey wheel repeated the same instruction forever | if a draft is already chosen, tapping the wheel **retries** the unlock |
| `/rg-build-check.php` covered the stylesheet only | it also reports the card's campaign, odds, dates and this browser's spin |

Proof: `node tools/test-review-flow.mjs` → **204/204**, including

```
  PASS  picking a draft through the radio unlocks the wheel
  PASS  the same tap turns on "Review us on Google"
  PASS  a chosen draft never leaves the wheel locked
  PASS  touching the draft text also unlocks the wheel
  PASS  a failed unlock leaves the wheel locked
  PASS  a failed unlock tells the customer something
  PASS  tapping the wheel retries the unlock and it lands
```
