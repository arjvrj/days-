# Popup & Promotion Manager

Admin → **Marketing → Popup & Promotions** lets the site owner create a promotion,
upload its artwork, choose when and where it appears, publish it, edit it, pause it
and delete it — with no code change and no redeploy. The popup then appears on the
public marketing pages by itself, because those pages read the campaign out of the
database on every request.

This document explains what was added, how the rules work, how to use the screen,
and what was proved by tests.

---

## 1. What was added

| File | Purpose |
|---|---|
| `sql/schema.sql`, `app/install.php`, `sql/migrations/2026-11-popups.sql` | The `popups` table (24 columns, 3 indexes). A fresh install creates it; an existing site gets it from the migration. |
| `app/includes/popups.php` | The whole feature in one place: the page registry, validation, image rules, status maths, save / delete / enable-disable, reads, and the renderer. |
| `app/owner_marketing.php` | The owner screen: campaign list with stat cards, the editor, and a preview. |
| `app/assets/css/popup.css` | The popup itself, on the visitor's page. |
| `app/assets/js/popup.js` | Trigger, frequency, dismissal memory, clipboard, counters. |
| `app/popup_event.php` | Receives one impression or one click. |
| `app/includes/owner_layout.php` | A **Marketing** entry in the owner navigation. |
| `app/home.php`, `app/login.php`, `app/signup.php` | The three pages that can show a popup. |
| `tools/build-home.mjs` | The homepage generator emits the popup hook, so a rebuild does not lose it. |
| `tests/php/test_popups.php`, `tools/test-popups.mjs` | 98 rule checks and 96 browser checks. |

There is one table and one new screen. Nothing existing was replaced, and no second
admin system was created: the screen lives inside the panel that was already there,
under a new **Marketing** heading.

---

## 2. The campaign list

Open **Marketing → Popup & Promotions**. The top row shows five cards:

* **Total campaigns**
* **Active** — published and inside its dates
* **Scheduled** — published, but the start date is still in the future
* **Expired** — the end date has passed
* *(Impressions / Clicks)* — the running totals of the whole list

Below that is the table: thumbnail, campaign name, status, start date, end date,
impressions, clicks, and the four actions — **Edit**, **Preview**, **Enable** /
**Disable**, **Delete**. **+ Create New Popup** sits above the table.

Status is never typed by hand. It is worked out from two sources, in this order:

1. the switch — `draft` and `paused` mean "do not show this", whatever the dates say;
2. the dates — before `starts_at` it is **scheduled**, after `ends_at` it is
   **expired**, between them it is **active**.

So a Diwali campaign scheduled for 1–12 November becomes live on its own at
midnight on the 1st and stops on its own at the end of the 12th. Publishing needs no
redeploy because the visitor's page reads the table on every request.

---

## 3. The editor

**+ Create New Popup** opens one form. Fields, in the order they appear:

**A. Campaign name** — internal only. It is what you see in the list; visitors
never see it. e.g. *Diwali 2026 Special Offer*.

**B. Image** — choose a file from your device (JPG, PNG, WebP or GIF). It previews
immediately, can be **replaced**, and can be **removed**. Before anything is saved
the file is checked:

| Check | Rule | Why |
|---|---|---|
| It really is an image | read from the file header with `getimagesize()`, not from the extension | a renamed PHP file cannot get in |
| Size | 4 MB maximum | it has to load on a phone |
| Each side | 320 px to 4000 px | smaller looks broken, larger is wasted bytes |
| Shape | ratio between 0.5 and 2.0 | anything more extreme can only be shown by cropping it |
| Storage | `assets/uploads/popup-<16 hex>.<ext>` via the existing upload folder | no new storage system |

4:5 and 1:1 are recommended. Whatever you upload is shown with `object-fit: contain`,
so **no part of your artwork is ever cropped or stretched** — the popup gets narrower
or wider around it.

**C. Heading** (optional, 160 characters), **D. Description** (optional, 400
characters).

**E. Call to action** — a switch, the button text, the destination URL, and
same tab / new tab. The text can be anything ("Claim Offer", "Get Started",
"Explore Plans", "Buy Now", "Learn More" are offered as suggestions). The URL is
checked with the same safe-URL function the rest of the site uses, so
`javascript:` and `data:` links are refused at save time **and** refused again at
render time.

**F. Coupon code** (optional, 40 characters, letters/digits/`-`/`_`). It is shown in
a dashed lavender box with a **Copy code** button. The button writes to the real
clipboard (`navigator.clipboard.writeText`, with a hidden-textarea fallback for older
browsers) and then says *Copied* with a polite live-region message. Typing
`review30` is stored as `REVIEW30`.

Below those, four layouts to choose from, and the display settings.

---

## 4. The four layouts

| Layout | What the visitor sees |
|---|---|
| **Image** | The artwork alone, as large as it can be. |
| **Image + text** | Artwork first, then heading and description. |
| **Image + CTA** | Artwork, then the button. |
| **Announcement** | A promotional strip above the text, artwork underneath — for a feature launch rather than a picture-led offer. |

All four use the brand palette: `#FBF8F2` page cream, `#FFFDFB` card, `#4B20DC`
purple, `#141623` navy, `#E7F3B7` lime, `#F1EBFE` lavender. Rounded corners
(24 px on the card, 14 px on the button), a soft layered shadow, and one quiet
entrance animation (the card rises 8 px and fades in). With
`prefers-reduced-motion: reduce`, the animation is turned off entirely.

The artwork is the hero in every layout: it takes the top of the card, up to 52 % of
the viewport height, and the text never pushes it out of the way.

---

## 5. Display settings

**Trigger**

| Option | How it behaves |
|---|---|
| Immediately | opens as soon as the page is ready |
| After a delay | waits N seconds (1–60) |
| After scrolling | waits until the visitor has scrolled N % (10–100) of the page |
| Exit intent | opens when the pointer leaves the top of the window — **desktop only**, and never on a touch device |

Exit intent is refused on any device that reports touch, and on narrow screens, so a
phone never gets it.

**Frequency**

| Option | Remembered for |
|---|---|
| Every visit | nothing is remembered |
| Once per session | this browser tab session |
| Once every 24 hours | one day |
| Once every 7 days | one week |
| Once per campaign | forever, until the browser's storage is cleared |

Dismissals are remembered the same way: closing the popup counts as "seen", so the
chosen frequency is respected whether the visitor clicked the button or the ×. The
memory is a key in `sessionStorage` / `localStorage` (`rgpop:<id>`); **no row is
written for a view or a dismissal**, so the table does not grow with traffic.

**Nothing interrupts twice in one page view**: the script shows one popup, and a
second campaign on the same page waits for the next visit.

---

## 6. Where a popup can appear — and where it cannot

Page targeting offers four choices: homepage only, pricing only, selected public
pages, or all public marketing pages.

The list of pages that *can* show a popup is a fixed registry in the code:

```
home, pricing, login, signup
```

Only `app/home.php`, `app/login.php` and `app/signup.php` call `print_rg_popup()`.
The pricing option is ready for the pricing section as it becomes a page of its own.

**Hard exclusions.** These screens never include `popups.php`, so they cannot render
a popup even if the database is edited by hand:

* the logged-in business dashboard (`app/dashboard*.php`),
* the owner / admin panel (`app/owner_*.php`),
* the customer QR feedback and review flow (`app/review.php`).

A check inside `rg_popup_targets_match()` repeats the rule: a page key that is not in
the registry matches nothing, so `targets = 'all'` can never widen to a dashboard.
The customer feedback flow also never loads `popup.css` or `popup.js`, so there is
nothing there to interrupt a review being submitted.

A page that has no campaign for it does not download the popup's CSS or script at
all — the head tag is printed only when a campaign is actually waiting.

---

## 7. Counters

`app/popup_event.php` accepts `POST` with `id` and `kind` (`impression` or `click`):

* it refuses anything but `POST`;
* it refuses a request without a valid CSRF token, and a request whose `Origin`
  header is not this site;
* it refuses a campaign that is not live right now;
* it counts **at most one impression and one click per campaign per PHP session**,
  so a refresh or a double-click cannot inflate the numbers.

The browser sends the impression when the popup opens and the click when the button
is pressed (`fetch(..., { keepalive: true })`, so it survives the navigation).

---

## 8. How to use it

1. **Owner panel → Marketing → Popup & Promotions → + Create New Popup.**
2. Give it an internal name, e.g. *Diwali 2026 Special Offer*.
3. Upload the artwork. Watch the preview; the size and shape are checked before it
   is saved.
4. Add a heading, a line of description, a coupon code if the offer has one.
5. Switch the button on, type *Claim Offer*, point it at `/signup` or
   `https://…/pricing`, choose new tab if it leaves the site.
6. Pick a layout.
7. Choose the trigger (a 3-second delay is a good default) and the frequency
   (*once per session* is a good default).
8. Choose where: homepage only, or all marketing pages.
9. Set the dates if it is a seasonal offer, then set the status to **Active** and
   save. **Preview** shows it on the page before anyone else sees it.
10. When the season ends, either let the end date expire it or press **Disable**.

---

## 9. What the tests proved

**Rules — `tests/php/test_popups.php` (98 checks, all passing)**

```bash
node tools/php-run.mjs tests/php/test_popups.php \
  --require app/includes/payments.php --require app/includes/ai.php \
  --require app/includes/links.php --require app/includes/functions.php \
  --require app/includes/popups.php
```

* every state is reachable: draft, disabled, scheduled, active, expired — including
  the edges (an end date one second in the past is expired; the last second of the
  day is still live);
* targeting: `all` covers the marketing pages, `home` does not cover sign up, an
  unknown page key matches nothing, `all` is exclusive, case and spaces are cleaned;
* fields: coupon upper-cased and stripped to `[A-Z0-9_-]`, capped at 40; headings
  capped, control characters removed, non-Latin text kept whole; date fields become
  datetimes, the end date covers the whole day, junk dates become "no date";
* saving: no name → refused and nothing written; publishing with no image → refused;
  a button with no URL → refused; `javascript:` → refused; an end date before the
  start → refused; a complete campaign saves with normalised fields and returns its
  id; an absurd delay is clamped to 60; unknown trigger / frequency / layout fall back
  to safe defaults; an edit with no new image keeps the old one;
* images: a 400×500 PNG accepted, a PHP file renamed to `.png` refused, a 10:1 strip
  refused, a 100×100 refused, 9 MB refused, no file refused; stored names are random
  and cannot escape the upload folder; a traversal path or a remote URL is never
  rendered;
* markup: the popup prints on a targeted page and prints **nothing** on an untargeted
  one, on a paused one, an expired one, a scheduled one, one with no image, or an
  unknown page; it starts `hidden` so it cannot flash; it is a `aria-modal` dialog;
  a `<script>` heading and an attribute-breaking description are escaped; a stored
  `javascript:` URL is never put in an `href`; no button when the button is off;
* the dashboard counts: total / active / scheduled / expired / draft / disabled and
  the impression and click sums.

**Browser — `tools/test-popups.mjs` (96 checks, all passing)**

```bash
node tools/test-popups.mjs
```

The page under test is the app's own PHP, rendered by `tools/render-page.mjs`
against a stub database; the CSS and the script are the real files.

* the popup is on a targeted page, and a page with no campaign has neither the
  markup nor the CSS nor the script;
* a pricing-only campaign does **not** appear on the homepage;
* hidden at load, opens after the configured delay, then shows the owner's heading,
  description and coupon;
* the artwork is shown with `object-fit: contain` and the file really loads;
* exactly one impression is posted, with the campaign id, the CSRF token, and the
  kind; the button posts exactly one click;
* the Copy button puts `REVIEW30` on the real clipboard and the button reports it;
* the close button, Escape and the backdrop all close it, and the page scrolls again;
* after closing, a reload does not show it again (once per session); clearing
  storage brings it back;
* an "all pages" campaign appears on the log in page;
* the announcement layout puts the text above the artwork;
* the dashboard and the customer review page carry no popup markup, CSS or script,
  and the owner panel does not load the public popup either;
* on a 390 px phone it opens as a full-width sheet at the bottom, the close button is
  tappable, the button is at least 44 px high, and there is no horizontal scrolling;
* with reduced motion the animations are `none`;
* the owner screen lists campaigns with statuses, impressions, clicks, and every
  action, plus a Marketing entry in the navigation; the empty state explains what to
  do; and the owner-only rule (`requireOwner()` before any action, `requireCsrf()`,
  POST-only counters, origin check) is asserted against the source;
* the editor really contains what the brief asked for: name, file upload with a live
  preview of the current artwork, remove-image, heading, description, coupon, the
  button switch with its text, destination and new-tab choice, the four layouts, the
  four triggers with their value, the five frequencies, the target pages and the
  "all pages" choice, both dates, the status switch, and it posts as a file upload.

Screenshots: `docs/screenshots/popup-desktop.png`,
`docs/screenshots/popup-mobile.png`, `docs/screenshots/owner-marketing-view.png`,
`docs/screenshots/owner-marketing-editor.png`.

---

## 10. Honest limits

* There is no MySQL server, PHP binary or Apache in the build sandbox. The SQL was
  checked for parity (`check-schema.mjs`), executed against a stub in PHP, and the
  pages were rendered by a PHP runtime — but the first real query against MySQL
  happens on your host.
* The migration has to be run once on an existing site
  (`sql/migrations/2026-11-popups.sql`); a fresh install creates the table itself.
* Exit intent is a desktop convention, not a science: it fires when the pointer
  leaves the top of the window. Some browsers with unusual pointer handling may need
  two attempts before it triggers.
* "Once per campaign" lives in the visitor's browser. A visitor who clears site data
  will see it again — that is the only way to remember it without a cookie banner.
* Impressions are counted once per PHP session per campaign, not once per page view,
  by design: the numbers are for judging a promotion, not for billing.
* The **Preview** button shows the campaign inside the owner panel. It does not
  change the live site, and it cannot be crawled into the public pages.
