<?php
/**
 * rg-build-check.php — one-page deploy check.
 *
 *   Open: https://yoursite.com/rg-build-check.php
 *
 * It answers three questions in plain text and nothing else:
 *   1. is the customer page script on this server the animated one?
 *   2. is the design stylesheet on this server the current one?
 *   3. is this site running with a database connection?
 *
 * It prints no passwords, no database names, no server paths, and nothing about
 * customers. Delete this file once your deploy is confirmed — it is a diagnostic,
 * not part of the product.
 */

header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store, max-age=0');

$app    = __DIR__;
$review = $app . '/review.php';
$css    = $app . '/assets/css/customer-reference.css';

function rg_yes_no($ok) { return $ok ? 'YES' : 'NO'; }

function rg_read($file, $bytes = 400000) {
    if (!is_file($file) || !is_readable($file)) return '';
    $fh = fopen($file, 'rb');
    $data = $fh ? fread($fh, $bytes) : '';
    if ($fh) fclose($fh);
    return (string)$data;
}

echo "ReviewGrow — deploy check\n";
echo str_repeat('=', 40) . "\n\n";

/* 1 — the customer page script */
if (!is_file($review)) {
    echo "review.php ................ MISSING\n";
    echo "  → the app files are not in this folder. If you extracted a ZIP, the\n";
    echo "    files are probably one level down (e.g. /public_html/last-day/).\n\n";
    $reviewCode = '';
} else {
    $reviewCode = rg_read($review);
    $animated   = strpos($reviewCode, 'requestAnimationFrame') !== false;
    $dock       = strpos($reviewCode, 'rg-social') !== false;
    $stamp      = strpos($reviewCode, 'rg-build') !== false;
    echo "review.php ................ found, " . date('Y-m-d H:i', (int)filemtime($review)) . "\n";
    echo "  wheel really spins ...... " . rg_yes_no($animated) . "\n";
    echo "  floating links markup ... " . rg_yes_no($dock) . "\n";
    echo "  build stamp present ..... " . rg_yes_no($stamp) . "\n";
    if (!$animated || !$dock) {
        echo "  → this is an OLD review.php. Re-upload the app/ contents over it.\n";
    }
    echo "\n";
}

/* 2 — the design stylesheet */
if (!is_file($css)) {
    echo "customer-reference.css .... MISSING\n";
    echo "  → upload assets/css/ (the whole assets folder).\n\n";
} else {
    $cssCode = rg_read($css);
    $dockCss = strpos($cssCode, 'rg-float') !== false;
    echo "customer-reference.css .... found, " . date('Y-m-d H:i', (int)filemtime($css))
       . ", " . number_format(filesize($css)) . " bytes\n";
    echo "  floating dock styles .... " . rg_yes_no($dockCss) . "\n";
    if (!$dockCss) {
        echo "  → this is an OLD stylesheet. Re-upload assets/css/customer-reference.css.\n";
    }
    echo "\n";
}

/* 3 — is the app installed and reachable */
$config = $app . '/config.php';
if (!is_file($config)) {
    echo "config.php ................ not created yet → open install.php once.\n";
} else {
    echo "config.php ................ present\n";
    $readable = is_readable($config);
    echo "  readable by PHP ......... " . rg_yes_no($readable) . "\n";
    if ($readable) {
        try {
            require_once $app . '/includes/db.php';
            global $conn;
            $ok = isset($conn) && $conn instanceof PDO;
            if ($ok) {
                $v = $conn->query('SELECT VERSION()')->fetchColumn();
                echo "  database ............... connected (server " . htmlspecialchars((string)$v, ENT_QUOTES) . ")\n";
            } else {
                echo "  database ............... NOT connected\n";
            }
        } catch (Throwable $e) {
            echo "  database ............... connection failed — check config.php\n";
        }
    }
}

/* 4 — the wheel for one card: /rg-build-check.php?slug=your-slug */
$slug = isset($_GET['slug']) ? preg_replace('/[^a-zA-Z0-9_-]/', '', (string)$_GET['slug']) : '';
if ($slug !== '') {
    echo "\n";
    echo "Wheel for /r/" . $slug . "/\n";
    echo str_repeat('-', 40) . "\n";

    $reviewCode = is_file($review) ? rg_read($review) : '';
    $wheelFile  = $app . '/includes/wheel.php';
    $wheelCode  = is_file($wheelFile) ? rg_read($wheelFile) : '';

    echo "  pick-a-draft endpoint ... " . (strpos($reviewCode, "action === 'choose'") !== false ? 'YES' : 'NO (this review.php predates it)') . "\n";
    echo "  unlock safety copy ...... " . (strpos($reviewCode, 'rg-wheel-unlock-shim') !== false ? 'YES (unlocks even with an older wheel.php)' : 'NO') . "\n";
    echo "  includes/wheel.php ...... " . ($wheelCode === '' ? 'MISSING' : (strpos($wheelCode, 'function rg_wheel_customer_answer') !== false ? 'current' : 'OLD (no unlock rules)')) . "\n";

    if ($wheelCode !== '' && strpos($reviewCode, "action === 'choose'") !== false
        && strpos($wheelCode, 'function rg_wheel_customer_answer') === false
        && strpos($reviewCode, 'rg-wheel-unlock-shim') === false) {
        echo "  MIXED UPLOAD ............ review.php is new, includes/ is not.\n";
        echo "  → upload includes/wheel.php, or the whole package, over the top.\n";
    }

    try {
        require_once $app . '/includes/functions.php';
        require_once $app . '/includes/wheel.php';

        $card = getCardBySlug($slug);
        if (!$card) {
            echo "  card .................... NOT FOUND (wrong slug?)\n";
        } else {
            echo "  card .................... found: " . htmlspecialchars((string)$card['name'], ENT_QUOTES) . "\n";

            $expired = !empty($card['expiry_date']) && strtotime((string)$card['expiry_date']) < time();
            echo "  card active ............. " . rg_yes_no(!$expired) . ($expired ? " (expiry " . $card['expiry_date'] . ")" : "") . "\n";

            $campaign = rg_wheel_campaign($conn, (int)$card['id'], false);
            if (!$campaign) {
                echo "  campaign ................ NONE — the wheel is not set up for this card\n";
            } else {
                echo "  campaign ................ id " . (int)$campaign['id']
                   . ", enabled " . (!empty($campaign['enabled']) ? 'YES' : 'NO')
                   . ", starts " . (($campaign['starts_at'] ?? '') ?: 'any time')
                   . ", ends " . (($campaign['ends_at'] ?? '') ?: 'never') . "\n";

                $open = rg_wheel_is_open($campaign);
                echo "  open right now .......... " . rg_yes_no($open) . ($open ? '' : " <- a closed campaign never unlocks") . "\n";

                $check = rg_wheel_validate($campaign['segments']);
                echo "  prize odds .............. " . rg_yes_no($check['ok'])
                   . " (" . count($campaign['segments']) . " prizes" . ($check['ok'] ? '' : ': ' . $check['error']) . ")\n";

                $part = rg_wheel_participation($conn, (int)$card['id']);
                $spins = rg_wheel_visitor_spins($conn, (int)$card['id']);
                echo "  this browser's spin ..... "
                   . (empty($spins[1]) ? 'not granted yet' : ('granted, status ' . $spins[1]['status']))
                   . "\n";
                echo "  this browser eligible ... " . rg_yes_no(!empty($part['eligible'])) . "\n";
            }
        }
    } catch (Throwable $e) {
        echo "  database ................ could not be read (" . get_class($e) . ")\n";
    }

    echo "\n  Tip: open the customer page on the SAME phone/browser you tested, or\n";
    echo "  the participation above belongs to a different visitor.\n";
}

echo "\n" . str_repeat('=', 40) . "\n";
echo "All YES above? Then the server has the new build — if the page still looks\n";
echo "old, it is a browser or proxy cache: hard-reload (Ctrl+Shift+R) or open a\n";
echo "private window. See docs/IF-THE-DESIGN-DID-NOT-CHANGE.md.\n\n";
echo "Delete this file (rg-build-check.php) when you are done.\n";
